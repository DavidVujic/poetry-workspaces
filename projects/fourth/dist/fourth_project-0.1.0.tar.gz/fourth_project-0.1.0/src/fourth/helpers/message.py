def get_message():
    return "hello world from a Poetry project"
