from fourth.helpers.message import get_message


def hello():
    return get_message()
