def get_message():
    return "Hello World from the Greet component"
