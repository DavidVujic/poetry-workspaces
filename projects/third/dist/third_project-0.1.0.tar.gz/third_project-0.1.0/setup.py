# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'libs/hello'}

packages = \
['third', 'world']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'third-project',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'David Vujic',
    'author_email': '@davidvujic',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
