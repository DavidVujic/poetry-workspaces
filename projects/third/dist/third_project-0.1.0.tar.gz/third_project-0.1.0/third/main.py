from world import hello


def run():
    return hello.hello()


run()
